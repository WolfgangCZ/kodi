from dataclasses import dataclass
from abc import ABC, abstractmethod


